package upmc.telegraphe.model;

import java.util.ArrayList;

public class MessageRoom {
    private ArrayList<String> messages;
    public MessageRoom() {
        messages = new ArrayList();
    }
    
    synchronized public void pushMsg(String pseudo, String msg) {
        messages.add(pseudo + ": " + msg);
    }
    
    public ArrayList<String> readMsg() {
        return messages;
    }
}
