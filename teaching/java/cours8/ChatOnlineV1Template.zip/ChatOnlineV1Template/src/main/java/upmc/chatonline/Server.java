package upmc.chatonline;

import java.net.*;
import java.io.*;

/* This server can only accepts one client. The server is stopped
*  when this client timed out or if it sends the message "\quit".
*/

public class Server {
  public static void main(String[] args) {
    System.out.println("Starting server...");
    // ... it's time to w-w-w-w-work!!
    System.out.println("Server shutted down.");
  }
}
