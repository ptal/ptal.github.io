package upmc.game;


class Axe extends Weapon {
  private static final double DAMAGE = 10;
  public Axe() {
    super(DAMAGE);
  }
}
