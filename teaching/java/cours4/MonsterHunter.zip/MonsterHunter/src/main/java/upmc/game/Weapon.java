package upmc.game;

class Weapon {
  protected double damage ;
  public Weapon ( double damage ) {
    this.damage = damage;
  }
}
