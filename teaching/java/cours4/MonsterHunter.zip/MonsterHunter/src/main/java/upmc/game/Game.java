package upmc.game;

public class Game 
{
  public static void main( String[] args )
  {
    System.out.println("Dear adventurer! Welcome to Monster Hunter!");
  }
}
