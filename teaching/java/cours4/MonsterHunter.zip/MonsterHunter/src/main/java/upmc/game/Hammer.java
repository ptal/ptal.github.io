package upmc.game;

class Hammer extends Weapon {
  private static final double DAMAGE = 20;
  public Hammer() {
    super(DAMAGE);
  }
}