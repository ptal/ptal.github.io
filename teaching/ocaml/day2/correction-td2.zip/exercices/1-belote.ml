type couleur =
   Pique   | Coeur
 | Carreau | Trefle

type carte =
  | As of couleur
  | Roi of couleur
  | Dame of couleur
  | Valet of couleur
  | Petite of couleur * int

let valeur carte coul_atout =
  match carte with
    As c -> 11
  | Roi c -> 4
  | Dame c -> 3
  | Valet c -> if (c = coul_atout) then 20 else 2
  | Petite (c, 10) -> 10
  | Petite (c, 9) -> if(c= coul_atout) then 14 else 0
  | _ -> 0

let mon_jeu = valeur (Valet Carreau) Carreau
  + valeur (Petite(Trefle, 10)) Carreau
  + valeur (Petite(Coeur, 7)) Carreau
  + valeur (Petite(Carreau, 8)) Carreau
  + valeur (Petite(Pique, 9)) Carreau
