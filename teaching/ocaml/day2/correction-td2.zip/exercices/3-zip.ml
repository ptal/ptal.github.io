let zip l1 l2 =
  let rec aux acc l1 l2 =
    match l1, l2 with
    | [], _ | _, [] -> List.rev acc
    | head1 :: tail1, head2 :: tail2 ->
      aux ((head1, head2) :: acc) tail1 tail2
  in
  aux [] l1 l2