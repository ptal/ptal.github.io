type int_list = Empty | Value of (int * int_list)

(* Liste vide. *)
let empty = Empty
(* Ajoute un entier dans la liste. *)
let cons x l = Value (x, l)
(* Taille de la liste *)
let length =
  let rec aux acc = function
  | Empty -> 0
  | Value (_, l) -> aux (acc+1) l

let rec iter l f =
  match l with
  | Empty -> ()
  | Value (x, l) -> begin f l; iter l f end

let rec map l f =
  | Empty -> Empty
  | Value (x, l) -> Value (f x, map l f)

let fold_left f a l =
  let rec aux a = function
  | Empty -> a
  | Value (x, l) -> aux (f a x) l
