(* naive *)
let rec pow x n =
  if n = 0 then 1 else x * pow x (n-1)

(* recursive terminale *)
let pow' x n =
   let rec aux n r =
      if n = 0
      then r
      else aux (n - 1) (r * x)
   in aux n 1

let _ = Printf.printf "%d %d\n" (pow 3 4) (pow' 3 4)
