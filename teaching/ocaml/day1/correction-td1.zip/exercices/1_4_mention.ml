let _ =
  let x = Scanf.scanf "%d" (fun x -> x) in
  if x < 10 then
    let _ = Printf.printf "Echec" in ()
  else if x < 12 then
    let _ = Printf.printf "Peut mieux faire" in ()
  else if x < 14 then
    let _ = Printf.printf "Presque bien" in ()
  else if x < 17 then
    let _ = Printf.printf "Bien" in ()
  else if x <= 20 then
    let _ = Printf.printf "Votre enfant a t'il une vie ?" in ()
  else
    let _ = Printf.printf "N'importe quoi. Les notes sont sur 20 !" in ()
