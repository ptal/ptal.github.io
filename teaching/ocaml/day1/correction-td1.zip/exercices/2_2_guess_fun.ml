let ask_number_to_user () =
  let _ = Printf.printf "Devinez un nombre : " in
  let _ = flush_all () in
  Scanf.scanf "%d" (fun x -> x)

let generate_numbers () =
  let x = Random.int 7 in
  let y = Random.int 7 in
  let z = Random.int 7 in
  let _ = Printf.printf "Nombres choisis : %d %d %d\n" x y z in
  (x, y, z)

let wins_2_points n (x, y, z) =
  let bool2int b = if b then 1 else 0 in
  let b1 = n > x in
  let b2 = n > y in
  let b3 = n > z in
  let score = (bool2int b1) + (bool2int b2) + (bool2int b3) in
  score = 2

let wins_1_point n (x, y, z) = n = x || n = y || n = z

let round () =
  let n = ask_number_to_user () in
  let numbers = generate_numbers () in
  if wins_2_points n numbers then
    Printf.printf "Vous gagnez 2 points.\n"
  else if wins_1_point n numbers then
    Printf.printf "Vous gagnez 1 point.\n"
  else
    Printf.printf "Vous perdez.\n"

let _ = round ()