let rec print_line c =
  if c > 0 then
    let _ = Printf.printf "*" in
    print_line (c-1)
  else
    Printf.printf "\n"

let print_border c =
  let rec aux current =
    if current > 0 then
      let _ = Printf.printf " " in
      aux (current - 1)
  in
    let _ = if c > 1 then Printf.printf "*" else () in
    let _ = aux (c-2) in
    if c > 0 then Printf.printf "*\n"

let rec print_inner_rectangle l c =
  if l > 0 then
    let _ = print_border c in
    print_inner_rectangle (l-1) c

let print_rectangle l c =
  if l > 0 then
    let _ = print_line c in
    let _ = print_inner_rectangle (l-2) c in
    if l > 1 then
      print_line c

let _ =
    let lines = Scanf.scanf "%d\n" (fun x -> x) in
    let columns = Scanf.scanf "%d\n" (fun x -> x) in
    print_rectangle lines columns
