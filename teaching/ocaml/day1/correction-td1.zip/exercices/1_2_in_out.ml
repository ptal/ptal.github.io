let _ =
  let x = Scanf.scanf "%d" (fun x -> x) in
  let _ = Printf.printf "%d" x in ()