let _ =
  let rec print x =
    let _ = Printf.printf "%d\n" x in
    let _ = if x > 1 then print (x-1) else () in
    Printf.printf "%d\n" x
  in
    let x = Scanf.scanf "%d" (fun x -> x) in
    print x
