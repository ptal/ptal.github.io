let rec fib n =
  if n = 0 || n = 1 then
    1
  else
    fib (n-1) + fib (n-2)

let _ =
  let n = Scanf.scanf "%d" (fun x -> x) in
  let res = fib n in
  let _ = Printf.printf "Résultat : fib(%d) = %d" n res in
  ()