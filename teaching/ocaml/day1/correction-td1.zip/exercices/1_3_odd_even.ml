let _ =
  let x = Scanf.scanf "%d" (fun x -> x) in
  if x mod 2 = 0 then
    let _ = Printf.printf "%d is even" x in ()
  else
    let _ = Printf.printf "%d is odd" x in ()