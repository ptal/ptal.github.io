let _ =
  let _ = Printf.printf "Devinez un nombre : " in
  let _ = flush_all () in
  let n = Scanf.scanf "%d" (fun x -> x) in
  let x = Random.int 7 in
  let y = Random.int 7 in
  let z = Random.int 7 in
  let _ = Printf.printf "Nombres choisis : %d %d %d\n" x y z in
  let b1 = n > x in
  let b2 = n > y in
  let b3 = n > z in
  let score = (if b1 then 1 else 0) + (if b2 then 1 else 0) + (if b3 then 1 else 0) in
  if score = 2 then
    Printf.printf "Vous gagnez 2 points.\n"
  else if n = x || n = y || n = z then
    Printf.printf "Vous gagnez 1 point.\n"
  else
    Printf.printf "Vous perdez.\n"