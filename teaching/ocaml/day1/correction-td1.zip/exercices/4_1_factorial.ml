(* naive *)
let rec fact n =
  if n = 0 then 1 else n * fact (n - 1)

(* recursive terminale *)
let fact' n =
  let rec aux n r =
    if n = 0
    then r
    else aux (n - 1) (r * n)
  in aux n 1

let _ = Printf.printf "%d %d\n" (fact 10) (fact' 10)
