let _ =
  let rec print_line c =
    if c > 0 then
      let _ = Printf.printf "*" in
      print_line (c-1)
  in
  let rec print_rectangle l c =
    if l > 0 then
      let _ = print_line c in
      let _ = Printf.printf "\n" in
      print_rectangle (l-1) c
  in
    let lines = Scanf.scanf "%d\n" (fun x -> x) in
    let columns = Scanf.scanf "%d\n" (fun x -> x) in
    print_rectangle lines columns
