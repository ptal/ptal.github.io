module type OrderedType =
  sig
    type t
    val compare : t -> t -> int
  end


module Make(Ord: OrderedType) = struct

  type key = Ord.t
  type 'a t = Empty
            | Node of ('a * 'a t * 'a t)

  let create () = Empty

  let rec add k x m =
    match m with
    | Empty -> Node ((k,x),Empty,Empty)
    | Node((k',v),l,r) ->
       if Ord.compare k k' < 0 then
         Node((k',v),add k x l,r)
       else if Ord.compare k k' > 0 then
         Node((k',x),l, add k x r)
       else
         Node((k,x),l,r)

  let rec find k m =
    match m with
    | Empty -> raise Not_found
   | Node((k',v),l,r) ->
       if Ord.compare k k' = 0 then v
       else if Ord.compare k k' < 0 then
         find k l
       else
         find k r

end


module MapString = Make(String)

let _ =
  let m = MapString.create () in
  let m = MapString.add "lundi" 12 m in
  let m = MapString.add "mardi" 15 m in
  let m = MapString.add "mercredi" 22 m in
  m
