let rec fib = function x -> if x < 3 then 1 else (fib(x-1))+(fib(x-2));;

fib 3;;
