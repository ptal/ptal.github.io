let succ = function x -> x + 1;;

