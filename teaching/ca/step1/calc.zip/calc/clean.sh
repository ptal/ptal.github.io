#!/bin/sh

rm *.cmi; rm *.cmo; rm *.mli; rm calc; rm lexer.ml; rm parser.ml