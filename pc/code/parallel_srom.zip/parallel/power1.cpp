#include <iostream>
#include <vector>
#include <random>
#include <chrono>
#include <execution>
#include <algorithm>
#include "benchmark.hpp"

template <class RNG, class D>
std::vector<int> init_random_vector(size_t n, RNG& rng, D& d) {
  std::vector<int> v(n);
  std::generate(v.begin(), v.end(), [&d, &rng](){return d(rng);});
  return v;
}

int exp(int a, int e) {
  int r = 1;
  for(int i = 0; i < e; ++i) {
    r = a * r;
  }
  return r;
}

// g++ power1.cpp -O3 -march=native -ltbb -std=c++23 -o power
int main(int argc, char** argv) {
  int e = 10;
  if(argc == 2) {
    e = std::stoi(argv[1]);
  }
  size_t n = static_cast<size_t>(1000 * 1000 * 1000) * 1;
  std::cout << "Initializing " << ((n*sizeof(int)) / 1000 / 1000 / 1000) << " GB" << std::endl;

  std::mt19937 rng{0};
  std::uniform_int_distribution<> dist{0, 100};
  std::vector<int> x = init_random_vector(n, rng, dist);

  easy_bench("std::for_each(exp)", [&](){
    std::for_each(x.begin(), x.end(),
               [e](int& v){ v = exp(v, e); });
    return x[n/2] == 1;
  }, 2);

  easy_bench("std::for_each(par,exp)", [&](){
    std::for_each(std::execution::par, x.begin(), x.end(),
               [e](int& v){ v = exp(v, e); });
    return x[n/2] == 1;
  });
}
