#include <vector>
#include <chrono>
#include <iostream>
#include <cstring>

int main() {

  std::vector<int> v1(1000000000, 0);
  for(size_t i = 0; i < v1.size(); ++i) {
    v1[i] = i;
  }
  std::vector<int> v2(1000000000, 0);
  std::vector<int> v3(1000000000, 0);

  auto start = std::chrono::steady_clock::now();
  for(size_t i = 0; i < v1.size(); ++i) {
    v2[i] = v1[i];
  }
  auto end = std::chrono::steady_clock::now();
  std::cout << "Time copy in loop: " << std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count() << "ms\n";

  start = std::chrono::steady_clock::now();
  std::memcpy(v3.data(), v1.data(), v1.size() * sizeof(int));
  end = std::chrono::steady_clock::now();
  std::cout << "Time copy in memcpy: " << std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count() << "ms\n";

  
  

   // Just to prevent the optimizer to optimize away the copy code.
  int sum = 0;
  for(size_t i = 0; i < v1.size(); ++i) {
    sum += v2[i] + v3[i];
  }
  std::cout << "(to ignore) sum = " << sum << std::endl;


  return 0;
}