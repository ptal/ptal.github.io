#include <iostream>
#include <thread>
#include <vector>
#include <random>
#include <algorithm>
#include "../benchmark.hpp"

template <class RNG, class D>
std::vector<int> init_random_vector(size_t n, RNG& rng, D& d) {
  std::vector<int> v(n);
  std::generate(v.begin(), v.end(), [&d, &rng](){return d(rng);});
  return v;
}

template <class F>
void foreach(std::vector<int>& data, int start, int end, F f) {
  for(size_t i = start; i < end; ++i) {
    f(data[i]);
  }
}

void twice(int& v) {
  v = v * 2;
}

int main(int argc, char** argv) {
  size_t n = static_cast<size_t>(1000 * 1000 * 1000) * 1;
  if(argc == 2) {
    n = std::stoll(argv[1]);
  }
  std::cout << "Initializing " << ((n*sizeof(int)) / 1000 / 1000 / 1000) << " GB" << std::endl;
  std::mt19937 rng{0};
  std::uniform_int_distribution<> dist{0, 1};
  std::vector<int> data = init_random_vector(n, rng, dist);
  std::vector<int> data2 = data;

  std::thread t1([&]() { foreach(data, 0, data.size() / 2, twice); });
  std::thread t2([&]() { foreach(data, data.size() / 2, data.size(), twice); });

  t1.join();
  t2.join();

  size_t local_sum[2] = {0, 0};
  std::thread t3([&]() { local_sum[0] = std::reduce(data.cbegin(), data.cbegin() + data.size() / 2); });
  std::thread t4([&]() { local_sum[1] = std::reduce(data.cbegin() + data.size() / 2, data.cend()); });

  t3.join();
  t4.join();

  size_t global_sum = local_sum[0] + local_sum[1];

  // Verifying the correctness

  size_t sum = 0;
  for(size_t i = 0; i < data2.size(); ++i) {
    sum += data2[i] * 2;
  }
  if(global_sum != sum) {
    std::cout << "Detected a bug " << global_sum << " != " << sum << std::endl;
    return 1;
  }
  std::cout << "Correct algorithm" << std::endl;
  return 0;
}