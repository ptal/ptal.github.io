#include <iostream>
#include <vector>
#include <random>
#include <chrono>
#include <algorithm>
#include <execution>
#include "benchmark.hpp"

template <class RNG, class D>
std::vector<float> init_random_vector(size_t n, RNG& rng, D& d) {
  std::vector<float> v(n);
  std::generate(v.begin(), v.end(), [&d, &rng](){return d(rng);});
  return v;
}

size_t count(float a, const std::vector<float>& data) {
  size_t num = 0;
  for(size_t i = 0; i < data.size(); ++i) {
    if(data[i] == a) {
      ++num;
    }
  }
  return num;
}

/* Try this program with different compilation options:

1. No option: `g++ count.cpp -std=c++23 -o count`
2. -O3: `g++ count.cpp -std=c++23 -O3 -o count`
3. Dedicated arch: `g++ count.cpp -std=c++23 -O3 -march=native -o count`

*/

int main() {
  size_t n = static_cast<size_t>(1000 * 1000 * 1000) * 1;
  std::cout << "Initializing " << ((n*sizeof(float)) / 1000 / 1000 / 1000) << " GB" << std::endl;
  std::mt19937 rng{0};
  std::uniform_real_distribution<float> dist{0.0, 100.0};
  std::vector<float> data = init_random_vector(n, rng, dist);
  float a = dist(rng);

  easy_bench("custom count", [&]() { return count(a, data); });
  easy_bench("std::count", [&]() {
    return std::count(data.cbegin(), data.cend(), a);
  });
  easy_bench("std::count par", [&]() {
    return std::count(std::execution::par, data.cbegin(), data.cend(), a);
  });

  return 0;
}
