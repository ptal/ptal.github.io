#include <iostream>
#include <thread>
#include <vector>
#include <random>
#include <algorithm>
#include "benchmark.hpp"

template <class RNG, class D>
std::vector<int> init_random_vector(size_t n, RNG& rng, D& d) {
  std::vector<int> v(n);
  std::generate(v.begin(), v.end(), [&d, &rng](){return d(rng);});
  return v;
}

template <class F>
void foreach2(std::vector<int>& data, const std::vector<int>& data2, size_t start, size_t end, F f) {
  for(size_t i = start; i < end; ++i) {
    data[i] = f(data[i], data2[i]);
  }
}

int exp(int a, int b) {
  int r = 1;
  for(int i = 0; i < b; ++i) {
    r = a * r;
  }
  return r;
}

int main(int argc, char** argv) {
  int num_threads = 10;
  int num_chunks_per_threads = 10;
  if(argc == 3) {
    num_threads = std::stoi(argv[1]);
    num_chunks_per_threads = std::stoi(argv[2]);
  }
  size_t n = static_cast<size_t>(1000 * 1000 * 1000) * 1;
  std::cout << "Initializing " << ((n*sizeof(int)) / 1000 / 1000 / 1000) << " GB" << std::endl;
  std::mt19937 rng{0};
  std::uniform_int_distribution<> dist{0, 100};
  std::vector<int> data = init_random_vector(n, rng, dist);
  std::vector<int> data2 = data;
  std::vector<int> exponents(n, 1);

  std::vector<std::thread> threads;
  // Taking care of edge case (for very small arrays).
  num_threads = std::min(data.size(), (size_t)num_threads);
  // Rounding up.
  size_t chunk_size = (data.size() + num_threads - 1) / num_threads;

  for(size_t i = 0; i < chunk_size; ++i) {
    exponents[i] = 100;
  }

  // assign chunks to threads
  std::vector<std::pair<size_t, size_t>> tasks;
  chunk_size = (data.size() + num_chunks_per_threads - 1) / num_chunks_per_threads;
  for(size_t i = 0; i < n; i += chunk_size) {
    size_t start = i;
    size_t end = std::min(data.size(), start + chunk_size);
    tasks.push_back(std::make_pair(start, end));
  }

  std::cout << "thread_id,time_ms" << std::endl;
  for(int i = 0; i < num_threads; ++i) {
    threads.emplace_back([&, i]() {
      auto start_time = std::chrono::steady_clock::now();
      for(size_t k = i; k < tasks.size(); k += num_threads) {
        size_t start = tasks[k].first;
        size_t end = tasks[k].second;
        foreach2(data, exponents, start, end, [](int a, int b) { return exp(a, b); });
      }
      auto end_time = std::chrono::steady_clock::now();
      std::chrono::duration<double, std::milli> t = end_time - start_time;
      std::ostringstream oss;
      oss << i << "," << t << "\n";
      std::cout << oss.str(); // We make sure of the atomicity of the printing.
    });
  }

  for(int i = 0; i < num_threads; ++i) {
    threads[i].join();
  }

  // Verifying the correctness

  for(size_t i = 0; i < data.size(); ++i) {
    if(data[i] != exp(data2[i], exponents[i])) {
      std::cout << "Detected a bug at position " << i << ": " << data[i] << " != " << data2[i] * 2 << std::endl;
      return 1;
    }
  }
  return 0;
}