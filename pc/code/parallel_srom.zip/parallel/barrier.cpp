#include <iostream>
#include <thread>
#include <barrier>
#include <vector>
#include <random>
#include <algorithm>
#include "benchmark.hpp"

template <class RNG, class D>
std::vector<int> init_random_vector(size_t n, RNG& rng, D& d) {
  std::vector<int> v(n);
  std::generate(v.begin(), v.end(), [&d, &rng](){return d(rng);});
  return v;
}

template <class F>
void foreach(std::vector<int>& data, size_t start, size_t end, F f) {
  for(size_t i = start; i < end; ++i) {
    f(data[i]);
  }
}

void twice(int& v) {
  v = v * 2;
}

void work(int tid, std::vector<size_t>& local_sum, std::barrier<>& barrier, std::vector<int>& data, size_t chunk_size) {
  size_t start = tid * chunk_size;
  size_t end = std::min(data.size(), start + chunk_size);
  foreach(data, start, end, twice);
  local_sum[tid] = std::reduce(data.cbegin() + start, data.cbegin() + end);
  barrier.arrive_and_wait();
  if(tid == 0) {
    for(int i = 1; i < local_sum.size(); ++i) {
      local_sum[0] += local_sum[i];
    }
  }
}

int main(int argc, char** argv) {
  size_t n = static_cast<size_t>(1000 * 1000 * 1000) * 1;
  int num_threads = 2;
  if(argc == 2) {
    num_threads = std::stoi(argv[1]);
  }
  std::cout << "Initializing " << ((n*sizeof(int)) / 1000 / 1000 / 1000) << " GB" << std::endl;
  std::mt19937 rng{0};
  std::uniform_int_distribution<> dist{0, 1};
  std::vector<int> data = init_random_vector(n, rng, dist);
  std::vector<int> data2 = data;

  num_threads = std::min(data.size(), (size_t)num_threads);
  std::barrier<> barrier(num_threads); // number of threads.
  std::vector<size_t> local_sum(num_threads , 0);
  std::vector<std::thread> threads;

  // Starting the work!
  size_t chunk_size = (data.size() + num_threads - 1) / num_threads;
  for(int i = 0; i < num_threads; ++i) {
    threads.emplace_back([&, i, chunk_size]() {
      work(i, local_sum, barrier, data, chunk_size);
    });
  }

  // Joining
  for(int i = 0; i < threads.size(); ++i) {
    threads[i].join();
  }

  size_t global_sum = local_sum[0];

  // Verifying the correctness

  size_t sum = 0;
  for(size_t i = 0; i < data2.size(); ++i) {
    sum += data2[i] * 2;
  }
  if(global_sum != sum) {
    std::cout << "Detected a bug " << global_sum << " != " << sum << std::endl;
    return 1;
  }
  std::cout << "Correct algorithm" << std::endl;
  return 0;
}