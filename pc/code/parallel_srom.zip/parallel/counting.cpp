#include <iostream>
#include <vector>
#include <thread>

void print(int i) {
  std::cout << i << " " << std::endl;
}

// + example with std::jthread.

int main() {
  std::vector<std::jthread> threads;
  for(int i = 0; i < 10; ++i) {
    threads.emplace_back([i](){ print(i); });
  }
  // for(int i = 0; i < 10; ++i) {
  //   threads[i].join();
  // }
  return 0;
}