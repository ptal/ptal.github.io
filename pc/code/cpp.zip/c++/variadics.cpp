#include <iostream>

template <class... Ts>
struct Sizeof;

template <>
struct Sizeof<> {
  static const size_t value = 0;
};

template <class T, class... Ts>
struct Sizeof<T, Ts...> {
  static const size_t value = sizeof(T) + Sizeof<Ts...>::value;
};

template <class... Ts>
struct SizeofFold {
  static const size_t value = (sizeof(Ts) + ... + 0);
};

int main() {
  std::cout << SizeofFold<>::value << std::endl;
  std::cout << SizeofFold<int>::value << std::endl;
  std::cout << SizeofFold<int, double, int long long>::value << std::endl;
}
