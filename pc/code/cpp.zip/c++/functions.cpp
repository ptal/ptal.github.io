#include <iostream>
#include <vector>

int add(int a, int b) {
  return a + b;
}

void print(const std::vector<int>& v) {
  for (int i : v) {
    std::cout << i << std::endl;
  }
}

void addZero(std::vector<int>& v) {
  v.push_back(0);
}

int main(int argc, char** argv) {

  int d = add(2, 2);
  // std::cout << d << std::endl;

  std::vector<int> vec{1, 2, 3, 4};
  print(vec);

  addZero(vec);
  print(vec);

  return 0;
}