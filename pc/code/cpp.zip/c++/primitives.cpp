#include <iostream>
#include <cstdint>

int main(int argc, char** argv) {

  const unsigned int x = 1;
  // ++x;

  std::cout << "char: " << sizeof(char) << " bytes" << std::endl;
  std::cout << "short: " << sizeof(short) << " bytes" << std::endl;
  std::cout << "int: " << sizeof(int) << " bytes" << std::endl;
  std::cout << "long: " << sizeof(long) << " bytes" << std::endl;
  std::cout << "long long: " << sizeof(long long) << " bytes" << std::endl;
  std::cout << "float: " << sizeof(float) << " bytes" << std::endl;
  std::cout << "double: " << sizeof(double) << " bytes" << std::endl;
  std::cout << "long double: " << sizeof(long double) << " bytes" << std::endl;
  std::cout << "bool: " << sizeof(bool) << " bytes" << std::endl;

  // static_assert(sizeof(short) == 3);

  int16_t y = 10;

  std::cout << "int16: " << sizeof(int16_t) << " bytes" << std::endl;

  return 0;
}