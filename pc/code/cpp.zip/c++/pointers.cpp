#include <iostream>

void add(int& x, int y) {
  x = x + y;
}

void add2(int* px, int y) {
  *px = *px + y;
}

int main(int argc, char** argv) {
  int x = 5;

  add(x, 2);

  add2(&x, 2);

  int* px = &x;
  (*px)++;

  int** ppx = &px;

  std::cout << **ppx << std::endl;

  return 0;
}