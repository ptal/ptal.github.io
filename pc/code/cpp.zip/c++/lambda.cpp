#include <iostream>
#include <vector>

template <class T>
void inc(std::vector<T>& vec) {
  for(T& v: vec) {
    v += 1;
  }
}

template <class T>
struct Increment {

  T operator() (T v) {
    return v + 1;
  }
};

template <class T>
struct Decrement {
  T operator() (T v) {
    return v - 1;
  }
};

template <class T, class F>
void map(std::vector<T>& vec, F f) {
  for(T& v: vec) {
    v = f(v);
  }
}

int main(int argc, char** argv) {

  std::vector<int> vec(10, 1);

  map(vec, Increment<int>{});
  map(vec, Decrement<int>{});

  map(vec, [&](auto n){ return n + vec.size(); });

  return 0;
}