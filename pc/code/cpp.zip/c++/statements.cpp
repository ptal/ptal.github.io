#include <iostream>
#include <vector>

int main(int argc, char** argv) {

  int x = 2;

  if(x == 0) {
    std::cout << x << std::endl;
  }
  else if(x == 1) {
    std::cout << x << std::endl;
  }
  else if(x == 2) {
    std::cout << x << std::endl;
  }
  else {
    std::cout << "final case" << std::endl;
  }

  switch (x) {
    case 0:
      std::cout << "print 0" << std::endl;
      break;

    case 1:
      std::cout << "print 1" << std::endl;
      break;

    case 2:
      std::cout << "print 2" << std::endl;
      break;

    default:
      std::cout << "print default" << std::endl;
      break;
  }

  while (x < 10) {
    std::cout << x << std::endl;
    x++;
  }

  for(int i = 0; i < x; ++i) {
    std::cout << "for loop version " <<  i << std::endl;
  }

  std::vector<int> v{1, 2, 3};

  for(int i = 0; i < v.size(); ++i) {
    std::cout << v[i] << std::endl;
  }

  std::cout << "RANGE FOR LOOP" << std::endl;

  for(int i: v) {
    std::cout << i << std::endl;
  }

  return 0;
}