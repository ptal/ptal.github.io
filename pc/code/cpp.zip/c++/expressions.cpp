#include <iostream>
#include <cstdint>

int main(int argc, char** argv) {

  int a = 10;
  int b = 15;
  int c = a + b - a / b * a % b;

  int d = ++a;
  a = a + 1;
  d = a;

  a /= 1;

  int e = a++;
  e = a;
  a = a + 1;

  int z = a == b ? 5 : 10;


  if(a = 11) {
    std::cout << "print something" << std::endl;
  }

  if(((!(a <= b)) && (c == 2)) || (a < 1)) {}

  uint8_t x = 2; // 0000 0010
  uint8_t y = 1; // 0000 0001

  std::cout << ~x << std::endl; //       1111 1101
  std::cout << (x & y) << std::endl; //  0000 0000
  std::cout << (x | y) << std::endl; //  0000 0011
  std::cout << ((x | y) ^ y) << std::endl; // 0000 0010

  x >> 1; // 0000 0001
  x << 1; // 0000 0100

  return 0;
}
