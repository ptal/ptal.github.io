#include <iostream>
#include <vector>
#include <unordered_map>
#include <random>

template <class T, class U>
void diagonal(std::vector<std::vector<T>>& vec2d, const U& v) {
  for(int i = 0; i < vec2d.size(); ++i) {
    vec2d[i][i] = v;
  }
}

void diagonal2(auto& vec2d, const auto& v) {
  for(int i = 0; i < vec2d.size(); ++i) {
    vec2d[i][i] = v;
  }
}

int sign(int v) {
  if(v < 0) return -1;
  else if(v > 0) return 1;
  else return 0;
}

auto histogram(const std::vector<int>& data) {

  auto hash = [](int v) {
    return v;
  };

  //hash map
  std::unordered_map<int, int, decltype(hash)> dict(3, hash);

  dict[-1] = 0;
  dict[0] = 0;
  dict[1] = 0;

  for(int v : data) {
    dict[sign(v)]++;
  }

  return dict;
}

void randomize(std::vector<int>& vec) {
  std::random_device rd;
  std::mt19937 g{rd()};
  std::uniform_int_distribution<> dist{-10, 10};
  for(int& v : vec) {
    v = dist(g);
  }
}

int main(int argc, char** argv) {

  using Vec2D = std::vector<std::vector<int>>;

  Vec2D matrix(3, std::vector<int>(3));
  auto matrix2(matrix);

  diagonal(matrix, 1.5);

  const auto& row = matrix[0];
  const std::vector<int>& row2 = matrix[0];

  std::vector<int> data(10);
  randomize(data);

  auto map = histogram(data);

  for(int v: data) {
    std::cout << v << " ";
  }
  std::cout << std::endl;

  for(std::pair<int, int> p: map) {
    std::cout << p.first << ": " << p.second << std::endl;
  }

  return 0;
}