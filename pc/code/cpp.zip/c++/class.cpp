#include <iostream>
#include <vector>

class Rule184 {
  private:
    size_t total_steps;
    std::vector<int> current;
    std::vector<int> next;

  public:
    Rule184() {
      total_steps = 0;
    }

    Rule184(size_t m)
      : current(m), next(m), total_steps(0)
    {}

    Rule184(const Rule184& other) = default;

    void print() const {
      for(const int& val : this->current) {
        std::cout << val << " ";
      }
      std::cout << std::endl;
    }

    void increment() {
      for(int& val : current) {
        val += 1;
      }
    }
};

int main(int argc, char** argv) {

  Rule184 rule184(10);

  Rule184 another_rule184(rule184);

  rule184.print();
  rule184.increment();
  rule184.print();

  return 0;
}