#include <iostream>

int main(int argc, char** argv) {

  int* x = new int{0};

  *x = 0;

  delete x;

  int* a = new int[1000000];

  for(int i = 0; i < 1000000; ++i) {
    a[i] = 0;
  }

  delete[] a;

  // *x = 3;

  // for(int i = 0; i < 1000000; ++i) {
  //   a[i] = 0;
  // }


  return 0;
}