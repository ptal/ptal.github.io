#include <iostream>
#include <cstdint>

template <class T>
class Vector {
  T* data;
  // ...

public:
  void who_am_i() const {
    std::cout << "I'm Vector<T> " << std::endl;
  }
};

template <>
class Vector<bool> {
  uint32_t* data;
  // ...

public:
  void who_am_i() const {
    std::cout << "I'm Vector<bool> " << std::endl;
  }
};

template <class T>
class Vector<Vector<T>> {
  T** data;
  // ...

public:
  void who_am_i() const {
    std::cout << "I'm Vector<Vector<T>> " << std::endl;
  }
};


int main() {
  Vector<int> a;
  a.who_am_i();

  Vector<bool> b;
  b.who_am_i();

  Vector<Vector<char>> c;
  c.who_am_i();

  return 0;
}
