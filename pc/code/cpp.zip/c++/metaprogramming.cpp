#include <iostream>

template <size_t i>
struct Factorial {
  static const size_t value = i * Factorial<i - 1>::value;
};

template <>
struct Factorial<0> {
  static const size_t value = 1;
};

constexpr size_t factorial(size_t val) {
  if(val == 0) {
    return 1;
  }
  else {
    return val * factorial(val - 1);
  }
}

int main() {
  std::cout << Factorial<3>::value << std::endl;
  static_assert(Factorial<3>::value == 6);

  static_assert(factorial(3) == 6);
  constexpr size_t f3 = factorial(3);

  size_t x;
  std::cin >> x;
  size_t fx = factorial(x);
  std::cout << "Factorial of x is " << fx << std::endl;

  return 0;
}
