#include <iostream>

template <class T>
class Vector {
private:
  size_t n;
  size_t capacity;
  T* array;

public:
  Vector() : n(0), capacity(0), array(nullptr) {};

  Vector(size_t n, const T& x = T())
  : n(n), capacity(n), array(new T[n])
  {
    for(size_t i = 0; i < n; ++i) {
      array[i] = x;
    }
  }

  Vector(Vector&& other)
  : n(other.n), capacity(other.capacity), array(other.array) {
    other.array = nullptr;
    other.n = 0;
    other.capacity= 0;
  }

  T& operator[](size_t i) {
    return array[i];
  }

  const T& operator[](size_t i) const {
    return array[i];
  }

  Vector& operator+=(const T& x) {
    for(size_t i = 0; i < n; ++i) {
      array[i] += x;
    }

    return *this;
  }

  ~Vector() {
    delete[] array;
  }
};

template <class T, class U>
struct Pair {
  T x;
  U y;

  Pair(const T& x, const U& y) : x(x), y(y) {}

  Pair(T&& x, U&& y) : x(std::move(x)), y(std::move(y)) {}
};

int main(int argc, char** argv) {

  Vector<int> vec(100);
  Vector<float> v;

  vec[0] = 1;
  // vec.operator[](0) = 2;
  std::cout << "first: " << vec[0] << std::endl;

  (vec += 5) += 2;

  
  Pair<Vector<int>, Vector<float>> p(std::move(vec), std::move(v));

  Vector<Pair<int, int>> p2;

  // p2 += 5;

  return 0;
}